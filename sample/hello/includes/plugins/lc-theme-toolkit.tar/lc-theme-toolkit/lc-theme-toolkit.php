<?php
/**
Plugin Name: LC Theme Toolkit
Plugin URI: http://lion-coders.com/
Description: Plugin for portfolio post type, demo importer, kingcomposer template and Social Share.
Version: 1.0
Author: LionCoders
Author URI: http://lion-coders.com/
*/
if(!class_exists('lcThemeToolkit')) {
	class lcThemeToolkit {
		public function __construct() {
			add_action('plugins_loaded', array($this, 'lc_theme_tollkit_load'));
		}
		public function lc_theme_tollkit_load() {
			if ( !function_exists( 'lc_theme_tollkit_data' ) ) {
				function lc_theme_tollkit_data() {
					register_post_type( 'portfolio', array(
						'labels'			=>	array(
							'name'			=>	__( 'Portfolio', 'hello' ),
							'add_new'		=>	__( 'Add New Portfolio', 'hello' ),
							'add_new_item'	=>	__( 'Add New Portfolio', 'hello' ),
						),
						'public'			=>	true,
						'supports'			=>	array( 'title', 'thumbnail', 'editor' ),
						'menu_icon'			=>	'dashicons-portfolio'
					) );
					register_taxonomy( 'portfolio-category', 'portfolio', array(
						'labels'			=>	array(
							'name'			=>	__( 'categories', 'hello' ),
							'add_new'		=>	__( 'Add New Category', 'hello' ),
							'add_new_item'	=>	__( 'Add New Category', 'hello' ),
						),
						'public'			=>	true,
						'show_admin_column' =>  true,
						'hierarchical'		=>	true
					) );
					if ( function_exists( 'kc_is_using' ) ) {
						global $kc;
						$kc->add_content_type( 'portfolio' );
						$kc->set_template_path( plugin_dir_path( __FILE__ ).'kingcomposer/');
					}
				}
				add_action('init', 'lc_theme_tollkit_data');
			}
		}
	}
}
$lc_theme_tollkit = new lcThemeToolkit();
include_once( 'kingcomposer/config.php' );