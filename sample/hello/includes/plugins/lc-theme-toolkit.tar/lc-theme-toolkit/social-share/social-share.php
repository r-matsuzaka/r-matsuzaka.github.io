<?php 
$hello_get_global_var = hello_global_var();
?>
<?php if ($hello_get_global_var['share_multi_checkbox']['1'] || $hello_get_global_var['share_multi_checkbox']['2'] || $hello_get_global_var['share_multi_checkbox']['3'] || $hello_get_global_var['share_multi_checkbox']['4']) : ?>
    <ul id="blog-social" class="unstyled">
    <?php if ($hello_get_global_var['social-share-title']) : ?>
        <li><?php echo esc_html($hello_get_global_var['social-share-title']); ?></li>
    <?php endif ?>
    <?php if ($hello_get_global_var['share_multi_checkbox']['1']) : ?>
        <li><a target="_blank" href="<?php $share_url = 'http://www.facebook.com/sharer.php?u='.get_the_permalink().'&amp;t='.urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); echo esc_url($share_url); ?>" title="<?php echo esc_attr__('Share this post on Facebook!', 'hello'); ?>"><i class="ion-social-facebook"></i></a></li>
    <?php endif ?>
    <?php if ($hello_get_global_var['share_multi_checkbox']['2']) : ?>
        <li><a target="_blank" href="<?php $share_url = 'http://twitter.com/home?status='.urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')).':'.get_the_permalink(); echo esc_url($share_url); ?>" title="<?php echo esc_attr__('Share this post on Twitter!', 'hello'); ?>"><i class="ion-social-twitter"></i></a></li>
    <?php endif ?>
    <?php if ($hello_get_global_var['share_multi_checkbox']['3']) : ?>
        <li><a target="_blank" href="<?php $share_url = 'https://plus.google.com/share?url='.get_the_permalink(); echo esc_url($share_url); ?>" title="<?php echo esc_attr__('Share this post on Google Plus!', 'hello'); ?>"><i class="ion-social-googleplus"></i></a></li>
    <?php endif ?>
    <?php if ($hello_get_global_var['share_multi_checkbox']['4']) : ?>
        <li><a target="_blank" href="<?php $share_url = 'http://pinterest.com/pin/create/button/?url='.get_the_permalink().'&media='.wp_get_attachment_url( get_post_thumbnail_id($post->ID) ).'&description='.urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); echo esc_url($share_url); ?>" class="pin-it-button" data-count-layout="horizontal" title="<?php echo esc_attr__('Share on Pinterest!', 'hello'); ?>"><i class="ion-social-pinterest"></i></a></li>
    <?php endif ?>                            
    </ul>
<?php endif ?>