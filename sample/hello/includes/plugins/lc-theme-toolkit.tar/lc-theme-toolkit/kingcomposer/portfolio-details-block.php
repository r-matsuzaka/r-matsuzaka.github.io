<?php 
$cover_style = $video_id = $slider_images = $cover_position = $category_word = $portfolio_info = '';
extract($atts);
if (is_singular( 'portfolio' )) :
?>
<div class="block-content">
    <?php if ($cover_position == 'yes'): ?>
    <div class="project-media <?php if ($cover_style != 2) { echo 'row'; } ?> text-center">
    	<?php if ( $cover_style == 1 ): ?>
	    	<?php if ( has_post_thumbnail() ): ?>
	        <div class="col-md-12">
	            <?php the_post_thumbnail(); ?>
	        </div>
	        <?php endif ?>
        <?php elseif ( $cover_style == 2 ): ?>
	        <div class="video-container">
	            <iframe src="http://www.youtube.com/embed/<?php echo esc_attr( $video_id ); ?>"></iframe>
	        </div>
        <?php elseif ( $cover_style == 3 ): ?>
	        <div id="lionslider" class="carousel slide" data-ride="carousel">
	            <div class="carousel-inner">
		        <?php 
		        $slider_images = explode( ',', $slider_images );

		        foreach( $slider_images as $image ) :
		            $image_data = wp_get_attachment_image_src( $image, 'full' );
		            $image_link = $image_data[0];
		            $alt_text = wptexturize(get_post_field( 'post_title', $image  ));   
		        ?>
	                <div class="carousel-item <?php if ($image==$slider_images[0]) { echo 'active'; } ?>">
	                	<img class="d-block w-100" src="<?php echo esc_url( $image_link ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
	                </div>
	            <?php endforeach; ?>
	            </div>
                <a class="carousel-control-prev" href="#lionslider" role="button" data-slide="prev">
                	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
                	<span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#lionslider" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
	        </div>
        <?php endif ?>
    </div>
    <?php endif ?>
    <div class="project-head">
        <h1 class="block-title"><?php the_title(); ?></h1>
        <div class="tags"><span><?php echo esc_html( $category_word ); ?></span>
        <?php
        $terms = get_the_terms( get_the_ID(), 'portfolio-category' ); 
        if ( $terms && ! is_wp_error( $terms ) ) {
            $cat_name = array();
            foreach ( $terms as $term ) {
                $cat_name[] = '<a href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $term->name ) . '</a>';
            }
          echo join( " / ", $cat_name);     
          }
        ?>
        </div>
        <?php if( isset( $portfolio_info ) ) : foreach( $portfolio_info as $port_item ) : 
        $port_title1 = $port_item->port_title1;
        $port_title2 = $port_item->port_title2;
        if ( !empty( $port_title1 ) || !empty( $port_title2 ) ) :
        ?>        
        <div class="tags"><span><?php echo esc_html( $port_title1 ); ?></span><?php echo esc_html( $port_title2 ); ?></div>
        <?php endif; endforeach; endif; ?>
    </div>
    <div class="project-description">
        <?php print $description; ?>
    </div>
    <?php if ($cover_position != 'yes'): ?>
    <div class="project-media <?php if ($cover_style != 2) { echo 'row'; } ?> text-center">
    	<?php if ( $cover_style == 1 ): ?>
	    	<?php if ( has_post_thumbnail() ): ?>
	        <div class="col-md-12">
	            <?php the_post_thumbnail(); ?>
	        </div>
	        <?php endif ?>
        <?php elseif ( $cover_style == 2 ): ?>
	        <div class="video-container">
	            <iframe src="http://www.youtube.com/embed/<?php echo esc_attr( $video_id ); ?>"></iframe>
	        </div>
        <?php elseif ( $cover_style == 3 ): ?>
	        <div id="lionslider" class="carousel slide" data-ride="carousel">
	            <div class="carousel-inner">
		        <?php 
		        $slider_images = explode( ',', $slider_images );

		        foreach( $slider_images as $image ) :
		            $image_data = wp_get_attachment_image_src( $image, 'full' );
		            $image_link = $image_data[0];
		            $alt_text = wptexturize(get_post_field( 'post_title', $image  ));   
		        ?>
	                <div class="carousel-item <?php if ($image==$slider_images[0]) { echo 'active'; } ?>">
	                	<img class="d-block w-100" src="<?php echo esc_url( $image_link ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
	                </div>
	            <?php endforeach; ?>
	            </div>
                <a class="carousel-control-prev" href="#lionslider" role="button" data-slide="prev">
                	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
                	<span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#lionslider" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
	        </div>
        <?php endif ?>
    </div>
    <?php endif ?>
    <div class="project-nav text-center">
        <span class="float-left">
        <?php previous_post_link( '%link', '&leftarrow; '.esc_html__( 'Previous Project', 'hello' ) ); ?>
        </span>
        <span>
            <a href="<?php the_permalink(); ?>"><i class="ion-grid"></i></a>
        </span>
        <span class="float-right">
        <?php next_post_link( '%link', esc_html__( 'Next Project', 'hello' ).' &rightarrow;' ); ?>
        </span>
    </div>
</div>
<?php endif ?>