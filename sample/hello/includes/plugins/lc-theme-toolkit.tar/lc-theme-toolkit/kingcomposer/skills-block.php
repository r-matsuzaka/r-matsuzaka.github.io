<?php 
$heading = $skills_list = '';
extract($atts);
?>

<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <?php if( isset( $skills_list ) ) : foreach( $skills_list as $skills_item ) : 
    $skill_title = $skills_item->skill_title;
    $years_experience = $skills_item->years_experience;
    $skill_percent = $skills_item->skill_percent;
    if ( !empty( $skill_title ) || !empty( $years_experience ) ) :
    ?>    
    <label class="progress-bar-label"><?php echo esc_html( $skill_title ); ?><span><?php echo esc_html( $years_experience ); ?></span></label>
    <div class="progress">
        <div style="width: <?php echo esc_attr( $skill_percent ); ?>" class="progress-bar" role="progressbar">
            <span><?php echo esc_html( $skill_percent ); ?></span>
        </div>
    </div>
    <?php endif; endforeach; endif; ?>
</div>
