<?php 
$heading = $testimonials_list = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="row">
        <div id="liontestimonial" class="owl-carousel owl-theme">
        <?php if( isset( $testimonials_list ) ) : foreach( $testimonials_list as $testimonials_item ) :
        $client_avatar = $testimonials_item->client_avatar;
        $client_name = $testimonials_item->client_name;
        $client_position = $testimonials_item->client_position;
        $testimonial = $testimonials_item->testimonial;
        if ( !empty( $client_name ) || !empty( $client_position ) ) :
        ?>
            <div class="item testimonials">
            <?php if ( !empty($client_avatar) ) :
            $avatar_data = wp_get_attachment_image_src( $client_avatar, 'full' );
            $avatar_link = $avatar_data[0];
            $alt_text = wptexturize(get_post_field( 'post_title', $client_avatar  ));
            ?>     
                <img src="<?php echo esc_url( $avatar_link ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>">
            <?php endif; ?>
                <blockquote><?php print $testimonial; ?>
                    <p class="quote"><span><?php echo esc_html( $client_name ); ?></span><?php echo esc_html( $client_position ); ?></p>
                </blockquote>
            </div>
        <?php endif; endforeach; endif; ?>
        </div>
    </div>
</div>