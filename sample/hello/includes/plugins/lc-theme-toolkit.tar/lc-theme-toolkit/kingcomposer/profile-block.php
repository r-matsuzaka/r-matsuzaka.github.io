<?php 
$heading = $subheading = $description = $info_list = $signature = '';
extract($atts);
?>

<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <h3 class="subheading"><?php print $subheading; ?></h3>
    <?php print $description; ?>
    <div class="info-list row">
        <?php if( isset( $info_list ) ) : foreach( $info_list as $info_item ) : 
        $info_title = $info_item->info_title;
        $info_text = $info_item->info_text;
        if ( !empty( $info_title ) || !empty( $info_text ) ) :
        ?>
        <div class="col-sm-6"><span><?php echo esc_html( $info_title ); ?></span><?php echo esc_html( $info_text ); ?></div>
        <?php endif; endforeach; endif; ?>
    </div>
    <?php if ( !empty($signature) ) :
            $sign_data = wp_get_attachment_image_src( $signature, 'full' );
            $sign_link = $sign_data[0];
            $alt_text = wptexturize(get_post_field( 'post_title', $signature  )); 
    ?>
    <img class="sign" src="<?php echo esc_url( $sign_link ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />    
    <?php endif; ?>
</div>          
