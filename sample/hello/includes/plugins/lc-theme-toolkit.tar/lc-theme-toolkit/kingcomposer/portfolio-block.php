<?php 
$heading = $category_name = $all_text = $number_item = $gap_items = $tc_hover = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="row">
        <div class="col-md-12">
            <div class="filters">
                <span><?php echo esc_html__('Filters :', 'hello'); ?></span>
                <ul id="filters" class="unstyled">
                    <li class="active" data-filter="*"><?php echo esc_html( $all_text ); ?></li>
	                <?php
	                  if (!empty($category_name)) {
	                    $category_name_arr = explode(':', $category_name);
	                      $portfolio = new WP_Query(array(
	                        'post_type'       =>  'portfolio',
	                        'posts_per_page'  =>  -1,
	                        'tax_query' => array(
	                            array(
	                             'taxonomy'   =>  'portfolio-category',
	                             'field' => 'slug', 
	                             'terms' => $category_name_arr[0]
	                              )
	                            )
	                      ));
	                  } else {
	                      $portfolio = new WP_Query(array(
	                          'post_type'       =>  'portfolio',
	                          'posts_per_page'  =>  -1
	                        )); 
	                  }                             
	                  $term_slug = array();
	                  $term_name = array();
	                  while($portfolio->have_posts()) {
	                     $portfolio->the_post();
	                     $terms = get_the_terms(get_the_id(), 'portfolio-category');
	                     if ( !empty( $terms ) ) {
		                     foreach ($terms as $term) {
		                      if (!in_array($term->name, $term_name )) {
		                          $term_slug[] = $term->slug;
		                          $term_name[] = $term->name;
		                          }
		                      }
		                  }
	                  }
	                  for ($i=0; $i<count($term_name); $i++) : 
	                ?>
	                <li data-filter=".<?php echo esc_attr($term_slug[$i]); ?>"><?php echo esc_html( $term_name[$i] ); ?></li>
	                <?php endfor; ?>
                </ul>
            </div>
            <div class="portfolio-container row isotope <?php if ($tc_hover != 'yes') { echo 'classic'; } ?>" id="portfolio-container">
            <?php
              while($portfolio->have_posts()) : $portfolio->the_post();
              $terms = get_the_terms(get_the_id(), 'portfolio-category');
              $term_slug = array();
              $term_name = array();
              if ( !empty( $terms ) ) {
                  foreach ($terms as $term) {
                    $term_slug[] = $term->slug;
                    $term_name[] = $term->name;
                  }                
              }
            ?>
                <div class="portfolio-item col-md-<?php echo 12/esc_html ($number_item ); ?> <?php echo join( " ", $term_slug) ?> <?php if ($gap_items != 'yes') { echo 'no-gutter'; } ?>">
                    <a class="open-project" href="<?php the_permalink(); ?>">
                        <div class="portfolio-column">
                        	<?php if ($tc_hover != 'yes'): ?>
                        		<?php the_post_thumbnail(); ?>
                                <div class="portfolio-content">
                                    <h2><?php the_title(); ?></h2>
                                    <p><?php echo join( " / ", $term_name) ?></p>
                                </div>                        		
                        	<?php else: ?>
	                            <div class="portfolio-hover">
	                                <div class="portfolio-content">
	                                    <h2><?php the_title(); ?></h2>
	                                    <hr>
	                                    <p><?php echo join( " / ", $term_name) ?></p>
	                                </div>
	                                <div class="portfolio-overlay"></div>
	                            </div>
	                            <?php the_post_thumbnail(); ?>
                            <?php endif ?>
                        </div>
                    </a>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
    </div>
</div>