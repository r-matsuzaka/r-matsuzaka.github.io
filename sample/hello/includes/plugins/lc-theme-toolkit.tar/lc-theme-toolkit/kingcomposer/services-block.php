<?php 
$heading = $service_list = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="row">
    <?php if( isset( $service_list ) ) : foreach( $service_list as $service_item ) : 
            $select_icon = $service_item->select_icon;
            $title = $service_item->title;
            $description = $service_item->description;
            if ( !empty( $title ) || !empty( $description ) ) :
            ?>        
        <div class="col-md-4 col-sm-6 service">
            <div class="service-icon">
                <i class="<?php echo esc_attr( $select_icon ); ?>"></i>
            </div>
            <h4><?php echo esc_html( $title ); ?></h4>
            <?php print $description; ?>
        </div>
    <?php endif; endforeach; endif; ?>
    </div>
</div>