<?php 
$heading = $edu_qual = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="timeline education">
        <div class="row">
            <div class="col-md-12">
                <div class="exp-holder">
                <?php if( isset( $edu_qual ) ) : foreach( $edu_qual as $edu_item ) : 
                $degree = $edu_item->degree;
                $institute = $edu_item->institute;
                $start_date = $edu_item->start_date;
                $startend_separator = $edu_item->startend_separator;
                $current = $edu_item->current;
                $current_text = $edu_item->current_text;
                $end_date = $edu_item->end_date;
                $description = $edu_item->description;
                if ( !empty( $degree ) || !empty( $institute ) ) :
                ?>                    
                    <div class="exp">
                        <div class="hgroup">
                            <h4><?php echo esc_html( $degree ); ?><span><?php echo esc_html( $institute ); ?></span></h4>
                            <h5><?php echo esc_html( $start_date ); ?><?php echo esc_html( $startend_separator ); ?><?php if ( !empty($current) ): ?><span class="current"><?php echo esc_html( $current_text ); ?></span><?php else: ?><?php echo esc_html( $end_date ); ?><?php endif; ?></h5>
                        </div>
                        <?php print $description; ?>
                    </div>
                <?php endif; endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
