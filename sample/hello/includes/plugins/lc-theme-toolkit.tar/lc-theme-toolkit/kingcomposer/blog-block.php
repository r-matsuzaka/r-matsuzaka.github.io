<?php
$hello_get_global_var = hello_global_var(); 
$heading = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title">
    <?php echo esc_html( $heading ); ?>
    </h3>
    <div class="row">
        <div class="col-md-10 mx-auto">
            <?php 
              $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
              $args = array(
                'post_type' => 'post',
                'paged'       => $paged
              );
              $wp_query = new WP_Query( $args );
            ?>
            <?php if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>          
            <div <?php post_class(); ?>>
                <?php if (has_post_thumbnail()): ?>
                <div class="post-thumbnail">
                    <a class="open-post" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail(); ?>
                    </a>
                </div>
                <?php endif ?>
                <div class="post-title">
                    <a class="open-post" href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2></a>
                    <p class="post-info">
                        <span class="post-author"><?php echo esc_html__('Posted by', 'hello'); ?> <?php the_author(); ?></span>
                        <span class="slash"></span>
                        <span class="post-date"><?php echo get_the_date(); ?></span>
                        <span class="slash"></span>
                        <span class="post-catetory"><?php the_category( ', ' ); ?></span>
                        <?php if (get_the_tags()) : ?>
                        <span class="slash"></span>
                        <span class="post-catetory"><?php the_tags( '', ', ', '' ); ?></span>
                        <?php endif ?>
                    </p>
                </div>
                <div class="post-body">
                    <p><?php echo wp_trim_words(get_the_content(), ($hello_get_global_var['blog-excerpt-length']) ? esc_html($hello_get_global_var['blog-excerpt-length']) : esc_html__('35', 'hello'), ''); ?></p>
                    <a class="btn read-more-btn open-post" href="<?php the_permalink(); ?>">
                    <?php 
                    if ($hello_get_global_var['blog-read-more']) {
                      echo esc_html($hello_get_global_var['blog-read-more']);
                    } else {
                      echo esc_html__('Read More', 'hello');
                    }
                    ?>
                    </a>
                </div>
            </div>
            <?php endwhile; else: ?>
            <p class="search-no-match"><?php echo esc_html__( 'Sorry, no posts matched your criteria.', 'hello' ) ?></p>
            <?php endif; wp_reset_postdata(); ?>
            <div class="text-center">
            <?php 
            $total_pages = $wp_query->max_num_pages; 
            $pagination = paginate_links( array(
                'total' => $total_pages,
                'type' => 'array',
                'prev_text' => esc_html__( 'Previous', 'hello' ),
                'next_text' => esc_html__( 'Next', 'hello' )
              ) ); ?>
            <?php if ( ! empty( $pagination ) ) : ?>
                <ul class="unstyled pagination">
                  <?php foreach ( $pagination as $key => $page_link ) : ?>
                    <li class="page-item <?php if ( strpos( $page_link, 'current' ) !== false ) { echo esc_attr( 'active' ); } ?>">
                    <?php echo str_replace('page-numbers','page-link',$page_link); ?>
                    </li>
                  <?php endforeach ?>
                </ul>
              <?php endif ?>
            </div>
        </div>
    </div>
</div>

