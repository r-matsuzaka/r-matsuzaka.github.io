<?php 
$heading = $experience_list = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="timeline experience">
        <div class="row">
            <div class="col-md-12">
                <div class="exp-holder">
                <?php if( isset( $experience_list ) ) : foreach( $experience_list as $experience_item ) : 
                $position = $experience_item->position;
                $company = $experience_item->company;
                $start_date = $experience_item->start_date;
                $startend_separator = $experience_item->startend_separator;
                $current = $experience_item->current;
                $current_text = $experience_item->current_text;
                $end_date = $experience_item->end_date;
                $description = $experience_item->description;
                if ( !empty( $position ) || !empty( $company ) ) :
                ?>                    
                    <div class="exp">
                        <div class="hgroup">
                            <h4><span><?php echo esc_html( $position ); ?></span><?php echo esc_html( $company ); ?></h4>
                            <h5><?php echo esc_html( $start_date ); ?><?php echo esc_html( $startend_separator ); ?><?php if ( !empty($current) ): ?><span class="current"><?php echo esc_html( $current_text ); ?></span><?php else: ?><?php echo esc_html( $end_date ); ?><?php endif; ?></h5>
                        </div>
                        <?php print $description; ?>
                    </div>
                <?php endif; endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
