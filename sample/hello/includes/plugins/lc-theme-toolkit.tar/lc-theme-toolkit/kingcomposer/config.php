<?php
add_action( 'init', 'hello_kingcomposer_extend' );
function hello_kingcomposer_extend() {	
	if( function_exists( 'kc_add_icon' ) ) {
		kc_add_icon( get_template_directory_uri().'/css/ionicons.min.css' );
	}	
	if (function_exists('kc_add_map')) { 		
		global $kc;
		$kc->add_map(
			array(				
				'menu-block'	=> array(
					'name'			=> __( 'Menu Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-star',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'menu_style',
								'type'			=> 'select',
								'label'			=> __('Menu Style', 'hello'),
								'options'		=> array(
									'1'	=> __('Box Menu', 'hello'),
									'2'	=> __('Inline Menu', 'hello')
								)
							),							
							array(
								'name'        => 'menu1_link',
								'label' 	  => __('Menu 1 Link', 'hello' ),
								'type'        => 'link',
								'relation'  	=> array(
									'parent'	=> 'menu_style',
									'show_when' => '1'
								)
							),						
							array(
								'name'        => 'menu2_link',
								'label' 	  => __('Menu 2 Link', 'hello' ),
								'type'        => 'link',
								'relation'  	=> array(
									'parent'	=> 'menu_style',
									'show_when' => '1'
								)
							),							
							array(
								'name'        => 'menu3_link',
								'label' 	  => __('Menu 3 Link', 'hello' ),
								'type'        => 'link',
								'relation'  	=> array(
									'parent'	=> 'menu_style',
									'show_when' => '1'
								)
							),							
							array(
								'name'        => 'menu4_link',
								'label' 	  => __('Menu 4 Link', 'hello' ),
								'type'        => 'link',
								'relation'  	=> array(
									'parent'	=> 'menu_style',
									'show_when' => '1'
								)
							)					
						)
					)
				),				
				'profile-block'	=> array(
					'name'			=> __( 'Profile Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-user',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'subheading',
								'label'			=> __( 'Subheading', 'hello' ),
								'type'			=> 'editor'
							),
							array(
								'name'			=> 'description',
								'label'			=> __( 'Description', 'hello' ),
								'type'			=> 'editor'
							)														
						),
						'info list'	=> array(
							array(
								'name'			=> 'info_list',
								'label'			=> __( 'Inforamtion List', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'			=> 'info_title',
										'label'			=> __('Info Title', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'info_text',
										'label' 	  => __('Info Text', 'hello' ),
										'type'        => 'text'
									)										
								)								
							),														
						),
						'signature'	=> array(
							array(
								'name'			=> 'signature',
								'label'			=> __( 'Signature', 'hello' ),
								'type'			=> 'attach_image',
							)														
						)												
					)
				),
				'skills-block'	=> array(
					'name'			=> __( 'Skills Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-sliders',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'skills_list',
								'label'			=> __( 'Skills List', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'			=> 'skill_title',
										'label'			=> __('Skill Title', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'years_experience',
										'label' 	  => __('Years of Experience', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'        => 'skill_percent',
										'label' 	  => __('Skill %', 'hello' ),
										'type'        => 'number_slider',
				                        'options' => array(
				                            'unit'		=> '%',
											'show_input'=> true
				                        )										
									)			
								)								
							)							
						)
					)
				),
				'experience-block'	=> array(
					'name'			=> __( 'Experience Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-industry',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'experience_list',
								'label'			=> __( 'Experience List', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'			=> 'position',
										'label'			=> __('Position', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'company',
										'label' 	  => __('Company', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'        => 'start_date',
										'label' 	  => __('Start Date', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'        => 'startend_separator',
										'label' 	  => __('Start & End Separator', 'hello' ),
										'type'        => 'text'
									),									
									array(
										'name'        => 'current',
										'label' 	  => __('End Date - Current', 'hello' ),
										'type'        => 'checkbox',
										'options' => array(
											'yes' => __('YES', 'hello' )
											)										
									),
									array(
										'name'        => 'current_text',
										'label' 	  => __('Current Text', 'hello' ),
										'type'        => 'text',
										'relation'  	=> array(
											'parent'	=> 'experience_list-current',
											'show_when' => 'yes'
										)										
									),
									array(
										'name'        => 'end_date',
										'label' 	  => __('End Date', 'hello' ),
										'type'        => 'text',
										'relation'  	=> array(
											'parent'	=> 'experience_list-current',
											'hide_when' => 'yes'
										)										
									),									
									array(
										'name'			=> 'description',
										'label'			=> __( 'Description', 'hello' ),
										'type'			=> 'editor'
									)									
								)								
							)							
						)
					)
				),
				'education-block'	=> array(
					'name'			=> __( 'Education Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-university',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'edu_qual',
								'label'			=> __( 'Educational qualifications', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'			=> 'degree',
										'label'			=> __('Degree', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'institute',
										'label' 	  => __('Institute', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'        => 'start_date',
										'label' 	  => __('Start Date', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'        => 'startend_separator',
										'label' 	  => __('Start & End Separator', 'hello' ),
										'type'        => 'text'
									),									
									array(
										'name'        => 'current',
										'label' 	  => __('End Date - Current', 'hello' ),
										'type'        => 'checkbox',
										'options' => array(
											'yes' => __('YES', 'hello' )
											)										
									),
									array(
										'name'        => 'current_text',
										'label' 	  => __('Current Text', 'hello' ),
										'type'        => 'text',
										'relation'  	=> array(
											'parent'	=> 'edu_qual-current',
											'show_when' => 'yes'
										)										
									),
									array(
										'name'        => 'end_date',
										'label' 	  => __('End Date', 'hello' ),
										'type'        => 'text',
										'relation'  	=> array(
											'parent'	=> 'edu_qual-current',
											'hide_when' => 'yes'
										)										
									),									
									array(
										'name'			=> 'description',
										'label'			=> __( 'Description', 'hello' ),
										'type'			=> 'editor'
									)									
								)								
							)							
						)
					)
				),
				'services-block'	=> array(
					'name'			=> __( 'Services Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-cubes',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'service_list',
								'label'			=> __( 'Service List', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'	      => 'select_icon',
										'label'	      => __('Select Icon', 'hello' ),
										'type'	      => 'icon_picker'
									),									
									array(
										'name'			=> 'title',
										'label'			=> __('Title', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'			=> 'description',
										'label'			=> __( 'Description', 'hello' ),
										'type'			=> 'editor'
									)										
								)								
							)							
						)
					)
				),
				'awards-block'	=> array(
					'name'			=> __( 'Awards Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-trophy',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'logo',
								'label' 		=> 'Logo',
								'type' 			=> 'attach_images'
							)							
						)
					)
				),
				'testimonials-block'	=> array(
					'name'			=> __( 'Testimonials Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-thumbs-up',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'			=> 'testimonials_list',
								'label'			=> __( 'Testimonials List', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(									
									array(
										'name'			=> 'client_name',
										'label'			=> __('Client\'s Name', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'			=> 'client_avatar',
										'label'			=> __( 'Client\'s Avatar', 'hello' ),
										'type'			=> 'attach_image',
									),									
									array(
										'name'        => 'client_position',
										'label' 	  => __('Client\'s Position', 'hello' ),
										'type'        => 'text'
									),
									array(
										'name'			=> 'testimonial',
										'label'			=> __( 'Testimonial', 'hello' ),
										'type'			=> 'editor'
									)					
								)								
							)							
						)
					)
				),
				'email-block'	=> array(
					'name'			=> __( 'Email Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-envelope',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'email',
								'label'			=> __( 'Email', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							)
						)
					)
				),
				'portfolio-block'	=> array(
					'name'			=> __( 'Portfolio Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-folder',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'        => 'category_name',
								'type'        => 'autocomplete',
								'label' 	  => __( 'Category', 'hello' ),
								'description' 	  => __( 'Insert the name of the category you want to pull posts from (optional)', 'hello' ),
							    'options'       => array(
							        'multiple' => false,
							        'taxonomy' => 'portfolio-category'
							    )
							),
							array(
								'name'        => 'all_text',
								'label' 	  => __( '"All" Text', 'hello' ),
								'type'        => 'text'
							),
							array(
								'name'			=> 'number_item',
								'type'			=> 'select',
								'label'			=> __('Items On Row', 'hello'),
								'options'		=> array(
									'1'	=> __('1 Item', 'hello'),
									'2'	=> __('2 Items', 'hello'),
									'3'	=> __('3 Items', 'hello')
								)
							),
							array(
								'name'        => 'gap_items',
								'type'        => 'toggle',
								'label' 	  => __( 'Gap Between Portfolio Items', 'hello' ),
							),
							array(
								'name'        => 'tc_hover',
								'type'        => 'toggle',
								'label' 	  => __( 'Title and Category on Hover', 'hello' ),
							),							
						)
					)
				),
				'blog-block'	=> array(
					'name'			=> __( 'Blog Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-pencil',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							)
						)
					)
				),
				'contact-block'	=> array(
					'name'			=> __( 'Contact Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-map-marker',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'heading',
								'label'			=> __( 'Heading', 'hello' ),
								'type'			=> 'text',
								'admin_label'	=> true
							),
							array(
								'name'        => 'slug',
								'type'        => 'select',
								'label'       => __( 'Select Contact Form', 'hello' ),
								'description' => __( 'Choose previously created contact form from the drop down list.', 'hello' ),
								'options'     => kc_tools::get_cf7_names()
							)						
						),
						'contact item'	=> array(
							array(
								'name'			=> 'contact_item',
								'label'			=> __( 'Contact Item', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'	      => 'select_icon',
										'label'	      => __('Select Icon', 'hello' ),
										'type'	      => 'icon_picker'
									),									
									array(
										'name'			=> 'item_title',
										'label'			=> __('Item Title', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'item_text',
										'label' 	  => __('Item Text', 'hello' ),
										'type'        => 'text'
									)										
								)								
							)														
						),
						'google map'	=> array(
							array(
								'name'			=> 'google_map_api_key',
								'label'			=> __( 'Google map API Key', 'hello' ),
								'type'			=> 'text'
							),
							array(
								'name'			=> 'latitude',
								'label'			=> __( 'Latitude', 'hello' ),
								'type'			=> 'text',
								"description" => '<a href="http://labs.mondeca.com/geo/anyplace.html" target="_blank">'.__('Here is a tool','hello').'</a> '.__('where you can find Latitude & Longitude of your location', 'hello')
							),
							array(
								'name'			=> 'longitude',
								'label'			=> __( 'Longitude', 'hello' ),
								'type'			=> 'text',
								"description" => '<a href="http://labs.mondeca.com/geo/anyplace.html" target="_blank">'.__('Here is a tool','hello').'</a> '.__('where you can find Latitude & Longitude of your location', 'hello')
							),
							array(
								'name'			=> 'marker_icon',
								'label'			=> __( 'Marker Icon', 'hello' ),
								'type'			=> 'attach_image',
							)														
						)												
					)
				),
				'portfolio-details-block'	=> array(
					'name'			=> __( 'Portfolio Details Block', 'hello' ),
					'category'    => __( 'By hello', 'hello' ),
					'icon'        => 'fa-folder-open',
					'params'		=> array(
						'general'	=> array(
							array(
								'name'			=> 'cover_style',
								'type'			=> 'select',
								'label'			=> __('Cover Style', 'hello'),
								'options'		=> array(
									'1'	=> __('Featured Image', 'hello'),
									'2'	=> __('Youtube Video', 'hello'),
									'3'	=> __('Slider', 'hello')
								)
							),
							array(
								'name'        => 'video_id',
								'type'        => 'text',
								'label' 	  => __('Video Id', 'hello' ),
								'description' 	  => __( 'Example: https://www.youtube.com/watch?v=<span style="color:red">5es64FPCO6k</span>. Here red number is the video id.', 'hello' ),
								'relation'  	=> array(
									'parent'	=> 'cover_style',
									'show_when' => '2'
								)
							),
							array(
								'name'        => 'slider_images',
								'type'        => 'attach_images',
								'label' 	  => __('Upload Slider Images', 'hello' ),
								'relation'  	=> array(
									'parent'	=> 'cover_style',
									'show_when' => '3'
								)
							),
							array(
								'name'        => 'cover_position',
								'type'        => 'toggle',
								'label' 	  => __( 'Position In Top?', 'hello' ),
								'description' => __( 'YES for top and NO for bottom', 'hello' ),
							)									
						),
						'info'	=> array(							
							array(
								'name'        => 'category_word',
								'label' 	  => __('\'Category\' Word', 'hello' ),
								'type'        => 'text'
							),
							array(
								'name'			=> 'portfolio_info',
								'label'			=> __( 'Portfolio Info', 'hello' ),
								'type'			=> 'group',
								'options'		=> array('add_text' => __('Add New', 'hello' )),
								'params' => array(
									array(
										'name'			=> 'port_title1',
										'label'			=> __('Title 1', 'hello' ),
										'type'			=> 'text'
									),
									array(
										'name'        => 'port_title2',
										'label' 	  => __('Title 2', 'hello' ),
										'type'        => 'text'
									)										
								)								
							)												
						),
						'description'	=> array(
							array(
								'name'			=> 'description',
								'label'			=> __( 'Description', 'hello' ),
								'type'			=> 'editor'
							)														
						)						
					)
				)			
			)						
		);
	} 		
}