<?php 
$heading = $logo = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="row">
    <?php if( !empty( $logo ) ) :
        $logo = explode( ',', $logo );
        foreach( $logo as $image ) :
            $logo_data = wp_get_attachment_image_src( $image, 'full' );
            $logo_link = $logo_data[0];
            $alt_text = wptexturize(get_post_field( 'post_title', $image  ));   
    ?>
        <div class="col-md-3 col-sm-6 awards">
            <img src="<?php echo esc_url( $logo_link ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
        </div>
    <?php endforeach; endif; ?>
    </div>
</div>