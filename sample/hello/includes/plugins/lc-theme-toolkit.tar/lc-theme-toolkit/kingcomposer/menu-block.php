<?php
$hello_get_global_var = hello_global_var();
$menu_style = $menu1_link = $menu2_link = $menu3_link = $menu4_link = '';
extract($atts);
if ( is_front_page() && !is_home() ) :
?>

<div id="menu-block-js" data-menu-block-js="jQuery('#page-content-block').removeClass('content-blocks');
    jQuery('#page-content').removeClass('content');
<?php if ( $hello_get_global_var['sidebar-menu']!=1 ) : ?>    
        <?php if ( $menu_style==1 ) : ?>
jQuery('.name-block').removeClass('reverse');
        jQuery('.name-block-container').removeClass('reverse');
        jQuery('.inline-menu-container').hide();
jQuery('.name-block').after('<div class=\'menu-blocks\'><?php if ( !empty( $menu1_link ) ): 
                        $menu1_link_arr = explode( '|', $menu1_link );
                        if ( !empty( $menu1_link_arr[0] ) ) {
                            $menu1_link_url = $menu1_link_arr[0];
                        } else {
                            $menu1_link_url = '#';
                        }
                        if ( !empty( $menu1_link_arr[2] ) ) {
                            $menu1_link_target = $menu1_link_arr[2];                    
                        }
                        if ( !empty( $menu1_link_arr[1] ) ) :
                            $menu1_link_title = $menu1_link_arr[1];
                        ?><a href=\'<?php echo esc_url( $menu1_link_url ); ?>\' title=\'<?php echo esc_attr( $menu1_link_title ); ?>\'<?php if (!empty( $menu1_link_target )): ?> target=\'<?php echo esc_attr( $menu1_link_target ); ?>\'<?php endif ?>><div class=\'about-block menu-block\'><div class=\'about-block-container\'><h2 class=\'about menu-item\'><?php echo esc_html( $menu1_link_title ); ?></h2></div></div></a><?php endif; endif ?><?php if ( !empty( $menu2_link ) ): 
                        $menu2_link_arr = explode( '|', $menu2_link );
                        if ( !empty( $menu2_link_arr[0] ) ) {
                            $menu2_link_url = $menu2_link_arr[0];
                        } else {
                            $menu2_link_url = '#';
                        }
                        if ( !empty( $menu2_link_arr[2] ) ) {
                            $menu2_link_target = $menu2_link_arr[2];                    
                        }
                        if ( !empty( $menu2_link_arr[1] ) ) :
                            $menu2_link_title = $menu2_link_arr[1];
                        ?><a href=\'<?php echo esc_url( $menu2_link_url ); ?>\' title=\'<?php echo esc_attr( $menu2_link_title ); ?>\'<?php if (!empty( $menu2_link_target )): ?> target=\'<?php echo esc_attr( $menu2_link_target ); ?>\'<?php endif ?>><div class=\'portfolio-block menu-block\'><div class=\'portfolio-block-container\'><h2 class=\'portfolio menu-item\'><?php echo esc_html( $menu2_link_title ); ?></h2></div></div></a><?php endif; endif ?><?php if ( !empty( $menu3_link ) ): 
                        $menu3_link_arr = explode( '|', $menu3_link );
                        if ( !empty( $menu3_link_arr[0] ) ) {
                            $menu3_link_url = $menu3_link_arr[0];
                        } else {
                            $menu3_link_url = '#';
                        }
                        if ( !empty( $menu3_link_arr[2] ) ) {
                            $menu3_link_target = $menu3_link_arr[2];                    
                        }
                        if ( !empty( $menu3_link_arr[1] ) ) :
                            $menu3_link_title = $menu3_link_arr[1];
                        ?><a href=\'<?php echo esc_url( $menu3_link_url ); ?>\' title=\'<?php echo esc_attr( $menu3_link_title ); ?>\'<?php if (!empty( $menu3_link_target )): ?> target=\'<?php echo esc_attr( $menu3_link_target ); ?>\'<?php endif ?>><div class=\'blog-block menu-block\'><div class=\'blog-block-container\'><h2 class=\'blog-block-menu menu-item\'><?php echo esc_html( $menu3_link_title ); ?></h2></div></div></a><?php endif; endif ?><?php if ( !empty( $menu4_link ) ): 
                        $menu4_link_arr = explode( '|', $menu4_link );
                        if ( !empty( $menu4_link_arr[0] ) ) {
                            $menu4_link_url = $menu4_link_arr[0];
                        } else {
                            $menu4_link_url = '#';
                        }
                        if ( !empty( $menu4_link_arr[2] ) ) {
                            $menu4_link_target = $menu4_link_arr[2];                    
                        }
                        if ( !empty( $menu4_link_arr[1] ) ) :
                            $menu4_link_title = $menu4_link_arr[1];
                        ?><a href=\'<?php echo esc_url( $menu4_link_url ); ?>\' title=\'<?php echo esc_attr( $menu4_link_title ); ?>\'<?php if (!empty( $menu4_link_target )): ?> target=\'<?php echo esc_attr( $menu4_link_target ); ?>\'<?php endif ?>><div class=\'contact-block menu-block\'><div class=\'contact-block-container\'><h2 class=\'contact menu-item\'><?php echo esc_html( $menu4_link_title ); ?></h2></div></div></a><?php endif; endif ?></div>');
        <?php else : ?>
        jQuery('body').addClass('menu2');
        if (jQuery(window).width() > 767) {
          jQuery('.inline-menu-container').addClass('style2');
        }
        jQuery('.status').hide();
        <?php endif ?>
    <?php endif ?>
    "></div>
<script>
    eval(jQuery('#menu-block-js').data('menu-block-js'));        
</script>
<?php else: ?>
<p><?php echo esc_html__( 'Menu Block element can only be used in Static Front Page.', 'hello' ) ?></p>
<?php endif ?>