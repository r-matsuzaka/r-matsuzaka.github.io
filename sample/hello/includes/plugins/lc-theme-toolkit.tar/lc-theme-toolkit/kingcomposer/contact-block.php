<?php 
global $wpdb;
$heading = $slug = $contact_item = $google_map_api_key = $latitude = $longitude = $marker_icon = '';
extract($atts);
?>
<div class="block-content">
    <h3 class="block-title"><?php echo esc_html( $heading ); ?></h3>
    <div class="row">
        <div class="<?php echo (empty( $contact_item ) ? 'col-md-12' : 'col-md-6'); ?>">
            <div id="contactForm">
            <?php
            $form = $wpdb->get_results("SELECT `ID` FROM `".$wpdb->posts."` WHERE `post_type` = 'wpcf7_contact_form' AND `post_name` = '".esc_attr(sanitize_title($slug))."' LIMIT 1");
            if( !empty( $form ) ){
                echo do_shortcode('[contact-form-7 id="'.$form[0]->ID.'"]');
            }else{
                echo __('Please select one of contact form 7 for display.', 'hello');
            }
            ?>   
            </div>
        </div>
        <?php if( !empty( $contact_item ) ) : ?>
        <div class="col-md-5 offset-md-1">
            <?php foreach( $contact_item as $con_item ) : 
                    $select_icon = $con_item->select_icon;
                    $item_title = $con_item->item_title;
                    $item_text = $con_item->item_text;
                    if ( !empty( $item_title ) || !empty( $item_text ) ) :
                    ?>
                <div class="contact-content">
                    <div class="contact-icon">
                        <i class="<?php echo esc_attr( $select_icon ); ?>"></i>
                    </div>
                    <div class="contact-details">
                        <h5><?php echo esc_html( $item_title ); ?></h5>
                        <p><?php echo esc_html( $item_text ); ?></p>
                    </div>
                </div>
            <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if ( !empty($google_map_api_key) && !empty($latitude) && !empty($longitude) ) :
            if ( !empty($marker_icon) ) {
                $marker_data = wp_get_attachment_image_src( $marker_icon, 'full' );
                $marker_link = $marker_data[0];
            }
        ?>        
        <div class="col-md-12">
            <!--Google Map-->
            <div id="map" data-mapjs="if (typeof google == 'undefined') {
                    jQuery.getScript('https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js( $google_map_api_key ); ?>', function() {                 
                        mapcreate();
                    });
                }
                else {
                    mapcreate();
                }
                function mapcreate() {
                    var latitude = '<?php echo esc_js( $latitude ); ?>';
                    var longitude = '<?php echo esc_js( $longitude ); ?>';
                    var markericon = '<?php echo esc_url( $marker_link ); ?>';        
                    var mapOptions = {
                        zoom: 11,
                        center: new google.maps.LatLng(latitude, longitude), 
                        scrollwheel: false,
                        styles: [{
                            featureType: 'all',
                            stylers: [{
                                saturation: -65
                            }]
                        }, {
                            featureType: 'road.arterial',
                            elementType: 'geometry',
                            stylers: [{
                                hue: '#00ffee'
                            }, {
                                saturation: 80
                            }]
                        }, {
                            featureType: 'poi.business',
                            elementType: 'labels',
                            stylers: [{
                                visibility: 'off'
                            }]
                        }]
                    };
                    var mapElement = document.getElementById('map');
                    var map = new google.maps.Map(mapElement, mapOptions);
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(latitude, longitude),
                        map: map,
                        icon: markericon,
                        draggable: true,
                        animation: google.maps.Animation.DROP
                    });
                    marker.addListener('click', toggleBounce);
                    function toggleBounce() {
                        if (marker.getAnimation() !== null) {
                            marker.setAnimation(null);
                        } else {
                            marker.setAnimation(google.maps.Animation.BOUNCE);
                        }
                    }                   
                }">
            </div>
            <!--Google Map End-->
        </div>
        <script type="text/javascript">
		    if (jQuery('#map').length > 0) { 
		    	eval(jQuery('#map').data("mapjs"));
			}
        </script>
        <?php endif; ?>
    </div>
</div>