<?php 
$email = '';
extract($atts);
?>
<div class="row text-center">
    <div class="col-md-12 btn-email">
        <a class="btn lowercase"><?php echo esc_html( $email ); ?></a>
    </div>
</div>